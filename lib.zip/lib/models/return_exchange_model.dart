// lib/models/return_exchange_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

enum ReturnExchangeType { returnGoods, exchangeGoods }
enum RequestStatus { pending, approved, rejected, completed }

extension ReturnExchangeTypeExtension on ReturnExchangeType {
  String get displayName {
    switch (this) {
      case ReturnExchangeType.returnGoods:
        return 'Trả hàng';
      case ReturnExchangeType.exchangeGoods:
        return 'Đổi hàng';
    }
  }
}

extension RequestStatusExtension on RequestStatus {
  String get displayName {
    switch (this) {
      case RequestStatus.pending:
        return 'Chờ xử lý';
      case RequestStatus.approved:
        return 'Đã duyệt';
      case RequestStatus.rejected:
        return 'Từ chối';
      case RequestStatus.completed:
        return 'Hoàn thành';
    }
  }

  String get colorHex {
    switch (this) {
      case RequestStatus.pending:
        return '#FF9800';
      case RequestStatus.approved:
        return '#4CAF50';
      case RequestStatus.rejected:
        return '#F44336';
      case RequestStatus.completed:
        return '#2196F3';
    }
  }
}

class ReturnExchangeRequest {
  final String id;
  final String userId;
  final String userName;
  final String userPhone;
  final String userEmail;
  final String orderId;
  final List<OrderItemReturn> items;
  final ReturnExchangeType type;
  final String reason;
  final String? customReason;
  final String? notes;
  final List<String> imageUrls;
  final RequestStatus status;
  final String? adminResponse;
  final String? adminId;
  final DateTime createdAt;
  final DateTime? updatedAt;

  ReturnExchangeRequest({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userPhone,
    required this.userEmail,
    required this.orderId,
    required this.items,
    required this.type,
    required this.reason,
    this.customReason,
    this.notes,
    this.imageUrls = const [],
    this.status = RequestStatus.pending,
    this.adminResponse,
    this.adminId,
    required this.createdAt,
    this.updatedAt,
  });

  factory ReturnExchangeRequest.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ReturnExchangeRequest(
      id: doc.id,
      userId: data['userId'] ?? '',
      userName: data['userName'] ?? '',
      userPhone: data['userPhone'] ?? '',
      userEmail: data['userEmail'] ?? '',
      orderId: data['orderId'] ?? '',
      items: (data['items'] as List?)
          ?.map((e) => OrderItemReturn.fromMap(e))
          .toList() ??
          [],
      type: ReturnExchangeType.values.firstWhere(
            (e) => e.toString() == data['type'],
        orElse: () => ReturnExchangeType.returnGoods,
      ),
      reason: data['reason'] ?? '',
      customReason: data['customReason'],
      notes: data['notes'],
      imageUrls: List<String>.from(data['imageUrls'] ?? []),
      status: RequestStatus.values.firstWhere(
            (e) => e.toString() == data['status'],
        orElse: () => RequestStatus.pending,
      ),
      adminResponse: data['adminResponse'],
      adminId: data['adminId'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: data['updatedAt'] != null
          ? (data['updatedAt'] as Timestamp).toDate()
          : null,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'userName': userName,
      'userPhone': userPhone,
      'userEmail': userEmail,
      'orderId': orderId,
      'items': items.map((e) => e.toMap()).toList(),
      'type': type.toString(),
      'reason': reason,
      'customReason': customReason,
      'notes': notes,
      'imageUrls': imageUrls,
      'status': status.toString(),
      'adminResponse': adminResponse,
      'adminId': adminId,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    };
  }

  Map<String, dynamic> toUpdateMap() {
    return {
      'status': status.toString(),
      'adminResponse': adminResponse,
      'adminId': adminId,
      'updatedAt': FieldValue.serverTimestamp(),
    };
  }
}

class OrderItemReturn {
  final String productId;
  final String productName;
  final String productImage;
  final double price;
  final int quantity;
  final String? selectedSize;
  final String? selectedColor;
  int? exchangeQuantity;

  OrderItemReturn({
    required this.productId,
    required this.productName,
    required this.productImage,
    required this.price,
    required this.quantity,
    this.selectedSize,
    this.selectedColor,
    this.exchangeQuantity,
  });

  factory OrderItemReturn.fromMap(Map<String, dynamic> map) {
    return OrderItemReturn(
      productId: map['productId'] ?? '',
      productName: map['productName'] ?? '',
      productImage: map['productImage'] ?? '',
      price: (map['price'] ?? 0).toDouble(),
      quantity: map['quantity'] ?? 1,
      selectedSize: map['selectedSize'],
      selectedColor: map['selectedColor'],
      exchangeQuantity: map['exchangeQuantity'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'productName': productName,
      'productImage': productImage,
      'price': price,
      'quantity': quantity,
      'selectedSize': selectedSize,
      'selectedColor': selectedColor,
      'exchangeQuantity': exchangeQuantity ?? quantity,
    };
  }
}