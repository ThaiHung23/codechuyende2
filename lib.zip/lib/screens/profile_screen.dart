import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/order_provider.dart';

import 'manage_products_screen.dart';
import 'manage_orders_screen.dart';
import 'ManageReturnScreen.dart';
import 'report_screen.dart';
import 'chat_screen.dart';
import 'ManageReturnScreen.dart';        // Admin quản lý yêu cầu
import 'return_request_screen.dart';       // Khách hàng tạo yêu cầu

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final isAdmin = authProvider.role == 'admin';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hồ sơ'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 30),

            // Avatar
            CircleAvatar(
              radius: 55,
              backgroundColor: Colors.red.shade100,
              child: const Icon(Icons.person, size: 70, color: Colors.red),
            ),
            const SizedBox(height: 12),

            Text(
              isAdmin ? 'Quản trị viên' : 'Đinh Thái Hùng',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),

            // ==================== THÔNG TIN KHÁCH HÀNG ====================
            if (!isAdmin)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        ListTile(
                          leading: Icon(Icons.person_outline),
                          title: Text('Họ và tên'),
                          subtitle: Text('Đinh Thái Hùng'),
                        ),
                        Divider(),
                        ListTile(
                          leading: Icon(Icons.phone),
                          title: Text('Số điện thoại'),
                          subtitle: Text('0392 790 228'),
                        ),
                        Divider(),
                        ListTile(
                          leading: Icon(Icons.email_outlined),
                          title: Text('Email'),
                          subtitle: Text('dinhthaihung1234@gmail.com'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            const SizedBox(height: 10),

            // ==================== MENU CHUNG ====================
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Lịch sử đơn hàng'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ManageOrdersScreen(isAdmin: false)),
              ),
            ),

            // ==================== TRẢ / ĐỔI HÀNG (KHÁCH HÀNG) ====================
            if (!isAdmin)
              ListTile(
                leading: const Icon(Icons.swap_horiz, color: Colors.orange),
                title: const Text('Trả / Đổi hàng'),
                subtitle: const Text('Gửi yêu cầu trả hoặc đổi sản phẩm'),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ManageOrdersScreen(isAdmin: false),
                  ),
                ).then((_) {
                  // Sau khi xem lịch sử đơn hàng, hỏi xem có muốn tạo yêu cầu không
                  // Hoặc bạn có thể tạo màn hình riêng liệt kê đơn để chọn
                }),
              ),

            // ==================== ADMIN MENU ====================
            if (isAdmin) ...[
              ListTile(
                leading: const Icon(Icons.inventory),
                title: const Text('Quản lý sản phẩm'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ManageProductsScreen())),
              ),
              ListTile(
                leading: const Icon(Icons.list_alt),
                title: const Text('Quản lý đơn hàng'),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ManageOrdersScreen(isAdmin: true)),
                ),
              ),

              // Quản lý yêu cầu Trả/Đổi (Admin)
              Consumer<OrderProvider>(
                builder: (context, provider, child) {
                  final pendingCount = provider.returnRequests
                      .where((r) => r.status == 'Đang xử lý')
                      .length;

                  return ListTile(
                    leading: const Icon(Icons.swap_horiz, color: Colors.orange),
                    title: Text('Quản lý Trả / Đổi hàng $pendingCount'),
                    subtitle: const Text('Duyệt yêu cầu từ khách hàng'),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ManageReturnsScreen()),
                    ),
                  );
                },
              ),

              ListTile(
                leading: const Icon(Icons.bar_chart),
                title: const Text('Báo cáo bán hàng'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportScreen())),
              ),
            ],

            // ==================== CHAT ====================
            ListTile(
              leading: const Icon(Icons.chat_bubble_outline, color: Colors.green),
              title: const Text('Chat với Admin'),
              subtitle: const Text('Hỗ trợ khách hàng 24/7'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())),
            ),

            const Divider(),

            // ==================== ĐĂNG XUẤT ====================
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Đăng xuất'),
              onTap: () {
                authProvider.logout();
                Navigator.pushReplacementNamed(context, '/');
              },
            ),
          ],
        ),
      ),
    );
  }
}