import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/order_provider.dart';
import '../models/return_request.dart';

class ReturnRequestScreen extends StatefulWidget {
  final String orderId;
  const ReturnRequestScreen({super.key, required this.orderId});

  @override
  State<ReturnRequestScreen> createState() => _ReturnRequestScreenState();
}

class _ReturnRequestScreenState extends State<ReturnRequestScreen> {
  ReturnType _selectedType = ReturnType.returnOnly;
  final TextEditingController _reasonController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Yêu cầu Trả / Đổi hàng'),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Đơn hàng #${widget.orderId}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),

            const Text('Loại yêu cầu:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 10),

            RadioListTile(
              title: const Text('Trả hàng (Hoàn tiền)'),
              value: ReturnType.returnOnly,
              groupValue: _selectedType,
              onChanged: (value) => setState(() => _selectedType = value!),
            ),
            RadioListTile(
              title: const Text('Đổi hàng (Sang sản phẩm khác)'),
              value: ReturnType.exchange,
              groupValue: _selectedType,
              onChanged: (value) => setState(() => _selectedType = value!),
            ),

            const SizedBox(height: 24),
            const Text('Lý do chi tiết:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            TextField(
              controller: _reasonController,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: 'Ví dụ: Sai size, sản phẩm lỗi, không vừa chân...',
                border: OutlineInputBorder(),
              ),
            ),

            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                onPressed: () {
                  if (_reasonController.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Vui lòng nhập lý do')),
                    );
                    return;
                  }

                  final request = ReturnRequest(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    orderId: widget.orderId,
                    type: _selectedType,
                    reason: _reasonController.text.trim(),
                  );

                  Provider.of<OrderProvider>(context, listen: false).addReturnRequest(request);

                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Yêu cầu đã được gửi thành công!')),
                  );
                },
                child: const Text('Gửi yêu cầu', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}