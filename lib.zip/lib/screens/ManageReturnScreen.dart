import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/order_provider.dart';
import '../models/return_request.dart';

class ManageReturnsScreen extends StatelessWidget {
  const ManageReturnsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orderProvider = Provider.of<OrderProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý Trả / Đổi hàng'),
        backgroundColor: Colors.red,
      ),
      body: orderProvider.returnRequests.isEmpty
          ? const Center(child: Text('Chưa có yêu cầu nào từ khách hàng'))
          : ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: orderProvider.returnRequests.length,
        itemBuilder: (context, index) {
          final req = orderProvider.returnRequests[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              title: Text('Đơn #${req.orderId}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Loại: ${req.typeText}'),
                  Text('Lý do: ${req.reason}'),
                  Text('Trạng thái: ${req.status}',
                      style: TextStyle(fontWeight: FontWeight.bold, color: _getStatusColor(req.status))),
                ],
              ),
              trailing: req.status == 'Đang xử lý'
                  ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.check_circle, color: Colors.green),
                    onPressed: () => orderProvider.updateReturnStatus(req.id, 'Đã duyệt'),
                  ),
                  IconButton(
                    icon: const Icon(Icons.cancel, color: Colors.red),
                    onPressed: () => orderProvider.updateReturnStatus(req.id, 'Từ chối'),
                  ),
                ],
              )
                  : null,
            ),
          );
        },
      ),
    );
  }

  Color _getStatusColor(String status) {
    if (status == 'Đã duyệt') return Colors.green;
    if (status == 'Từ chối') return Colors.red;
    return Colors.orange;
  }
}