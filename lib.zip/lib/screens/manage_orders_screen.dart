import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../providers/order_provider.dart';
import '../providers/product_provider.dart';
import '../models/cart_item.dart';

class ManageOrdersScreen extends StatelessWidget {
  final bool isAdmin;
  const ManageOrdersScreen({super.key, this.isAdmin = false});

  @override
  Widget build(BuildContext context) {
    final orderProvider = Provider.of<OrderProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lịch sử đơn hàng'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
      ),
      body: orderProvider.orders.isEmpty
          ? const Center(child: Text('Chưa có đơn hàng nào', style: TextStyle(fontSize: 18)))
          : ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: orderProvider.orders.length,
        itemBuilder: (context, index) {
          final order = orderProvider.orders[index];
          final mainItem = order.items.isNotEmpty ? order.items.first : null;

          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: mainItem != null
                    ? _buildProductImage(mainItem.shoe.imageUrl)
                    : const Icon(Icons.image_not_supported, size: 50),
              ),
              title: Text(
                mainItem?.shoe.name ?? 'Đơn hàng',
                style: const TextStyle(fontWeight: FontWeight.bold),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Ngày: ${DateFormat('dd/MM/yyyy HH:mm').format(order.date)}'),
                  Text('Trạng thái: ${order.status}', style: TextStyle(color: _getStatusColor(order.status))),
                  Text('Tổng tiền: ${order.total.toStringAsFixed(0)} VNĐ', style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () => _showOrderDetail(context, order),
            ),
          );
        },
      ),
    );
  }

  Widget _buildProductImage(String imageUrl) {
    if (imageUrl.startsWith('http')) return Image.network(imageUrl, width: 60, height: 60, fit: BoxFit.cover);
    if (imageUrl.startsWith('/') || imageUrl.contains('emulated')) {
      return Image.file(File(imageUrl), width: 60, height: 60, fit: BoxFit.cover);
    }
    return Image.asset(imageUrl, width: 60, height: 60, fit: BoxFit.cover);
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Đang xử lý': return Colors.orange;
      case 'Đã thanh toán': return Colors.indigo;
      case 'Đang giao': return Colors.deepOrange;
      case 'Đã giao': return Colors.green;
      case 'Đã hủy': return Colors.red;
      default: return Colors.grey;
    }
  }

  void _showOrderDetail(BuildContext context, dynamic order) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(mainItemName(order)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Ngày đặt: ${DateFormat('dd/MM/yyyy HH:mm').format(order.date)}'),
              Text('Trạng thái: ${order.status}'),
              const SizedBox(height: 8),
              Text('Địa chỉ: ${order.address}'),
              const Divider(),
              const Text('Sản phẩm:', style: TextStyle(fontWeight: FontWeight.bold)),
              ...order.items.map((CartItem item) => ListTile(
                dense: true,
                leading: _buildProductImage(item.shoe.imageUrl),
                title: Text(item.shoe.name),
                subtitle: Text('${item.size} - ${item.color} × ${item.quantity}'),
                trailing: Text('${(item.shoe.price * item.quantity).toStringAsFixed(0)}đ'),
              )),
              const Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Tổng cộng:', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text('${order.total.toStringAsFixed(0)} VNĐ', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Đóng')),
        ],
      ),
    );
  }

  String mainItemName(dynamic order) {
    return order.items.isNotEmpty ? order.items.first.shoe.name : 'Đơn hàng';
  }
}